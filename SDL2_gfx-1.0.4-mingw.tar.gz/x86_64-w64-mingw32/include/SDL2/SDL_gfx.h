#ifndef SDL_GFX_H
#define SDL_GFX_H

#include "SDL2_framerate.h"
#include "SDL2_gfxPrimitives.h"
#include "SDL2_imageFilter.h"
#include "SDL2_rotozoom.h"

#endif //SDL_GFX_H